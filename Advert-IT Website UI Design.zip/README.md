
  # Advert-IT Website UI Design

  This is a code bundle for Advert-IT Website UI Design. The original project is available at https://www.figma.com/design/xukHA6Ic4PXXJrQGtGIqgH/Advert-IT-Website-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  